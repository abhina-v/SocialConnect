package com.interestconnect.topic.service;

import com.interestconnect.topic.dto.CreateTopicRequest;
import com.interestconnect.topic.dto.UpdateTopicRequest;
import com.interestconnect.topic.dto.CreateTopicResponse;
import com.interestconnect.topic.dto.TopicResponse;
import com.interestconnect.topic.entity.Topic;
import com.interestconnect.topic.entity.TopicStatus;
import com.interestconnect.topic.repository.TopicRepository;
import com.interestconnect.user.entity.User;
import com.interestconnect.user.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TopicService {

    private final TopicRepository topicRepository;
    private final UserRepository userRepository;

    public TopicService(TopicRepository topicRepository,
                        UserRepository userRepository) {
        this.topicRepository = topicRepository;
        this.userRepository = userRepository;
    }

    public CreateTopicResponse createTopic(CreateTopicRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Topic topic = new Topic();

        topic.setTitle(request.getTitle());
        topic.setDescription(request.getDescription());
        topic.setTags(request.getTags());
        topic.setStatus(TopicStatus.LIVE);
        topic.setCreatedBy(user);

        Topic savedTopic = topicRepository.save(topic);

        return new CreateTopicResponse(
                savedTopic.getId(),
                savedTopic.getTitle(),
                savedTopic.getDescription(),
                savedTopic.getTags(),
                savedTopic.getStatus(),
                savedTopic.getCreatedBy().getName()
        );
    }

    public List<TopicResponse> getAllTopics() {

        List<Topic> topics = topicRepository.findByStatus(TopicStatus.LIVE);

        return topics.stream()
                .map(topic -> new TopicResponse(
                        topic.getId(),
                        topic.getTitle(),
                        topic.getDescription(),
                        topic.getTags(),
                        topic.getStatus(),
                        topic.getCreatedBy().getName()
                ))
                .toList();
    }
    public TopicResponse getTopicById(Long id) {

        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic not found"));

        return new TopicResponse(
                topic.getId(),
                topic.getTitle(),
                topic.getDescription(),
                topic.getTags(),
                topic.getStatus(),
                topic.getCreatedBy().getName()
        );
    }
    public List<TopicResponse> searchTopics(String tag) {

        List<Topic> topics = topicRepository.findByTagsContainingIgnoreCase(tag);

        return topics.stream()
                .map(topic -> new TopicResponse(
                        topic.getId(),
                        topic.getTitle(),
                        topic.getDescription(),
                        topic.getTags(),
                        topic.getStatus(),
                        topic.getCreatedBy().getName()
                ))
                .toList();
    }
    public TopicResponse updateTopic(Long id, UpdateTopicRequest request) {

        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic not found"));

        topic.setTitle(request.getTitle());
        topic.setDescription(request.getDescription());
        topic.setTags(request.getTags());

        Topic updatedTopic = topicRepository.save(topic);

        return new TopicResponse(
                updatedTopic.getId(),
                updatedTopic.getTitle(),
                updatedTopic.getDescription(),
                updatedTopic.getTags(),
                updatedTopic.getStatus(),
                updatedTopic.getCreatedBy().getName()
        );
    }
    public TopicResponse closeTopic(Long id) {

        Topic topic = topicRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Topic not found"));

        topic.setStatus(TopicStatus.CLOSED);

        Topic updatedTopic = topicRepository.save(topic);

        return new TopicResponse(
                updatedTopic.getId(),
                updatedTopic.getTitle(),
                updatedTopic.getDescription(),
                updatedTopic.getTags(),
                updatedTopic.getStatus(),
                updatedTopic.getCreatedBy().getName()
        );
    }
}