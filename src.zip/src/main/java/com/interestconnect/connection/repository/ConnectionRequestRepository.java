package com.interestconnect.connection.repository;

import com.interestconnect.connection.entity.ConnectionRequest;
import com.interestconnect.connection.entity.ConnectionStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ConnectionRequestRepository extends JpaRepository<ConnectionRequest, Long> {

    List<ConnectionRequest> findByReceiverIdAndStatus(Long receiverId, ConnectionStatus status);

    List<ConnectionRequest> findBySenderId(Long senderId);

}